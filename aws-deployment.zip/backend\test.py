import psycopg2
import os

host = "jobs.cxw8gaaqgjto.ca-central-1.rds.amazonaws.com"
port = 5432
dbname = "jobs"
user = "vikfor10"
password = "Frootloops33??!!"

conn = psycopg2.connect(host=host, port=port, dbname=dbname, user=user, password=password)

print("Connected to PostgreSQL on AWS RDS!!")

cur = conn.cursor()

cur.execute("SELECT datname FROM pg_database;")
print("Databases on this RDS instance:")
for db in cur.fetchall():
    print("-", db[0])


cur.close()
conn.close()

